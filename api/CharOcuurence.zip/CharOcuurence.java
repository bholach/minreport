import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CharOcuurence {

	public static void main(String args[]) throws FileNotFoundException
	   {
	        int i, j, k;
	        String str="";
	        char c, ch;
	        Scanner sc = new Scanner(System.in);
	        //importing file to java program
	        File file = new File("e://inputFile.txt");
	    	Scanner inputFile = new Scanner(file);
	    	
	    	System.out.print("Enter the character to be counted : ");
	    	c = sc.next().charAt(0);
	    	
	    	
	    	while(inputFile.hasNextLine()) {
	    		str += inputFile.nextLine();
	    	}
	        i=str.length();
	        //setting character to find

	            k=0;
	            for(j=0; j<i; j++)
	            {
	                ch = str.charAt(j);
	                if(ch == c)
	                {
	                    k++;
	                }
	            }
	            if(k>0)
	            {
	                System.out.println("The character " + c + " has occurred for " + k + " times");
	            }
	        }
    
}
